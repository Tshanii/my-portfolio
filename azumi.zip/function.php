<?php
function validateForm($name, $email, $message) {
    $errors = [];

    if (!preg_match("/^[a-zA-Z ]+$/", $name)) {
        $errors[] = "Name must contain only letters and spaces.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    $sanitizedMessage = strip_tags($message); 

    return $errors;
}


function connectDatabase() {
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "azumi";

    $connection = new mysqli($host, $username, $password, $database);

    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    return $connection;
}

function insertProject($title, $description, $imagePath, $connection) {
    $title = $connection->real_escape_string($title);
    $description = $connection->real_escape_string($description);
    $imagePath = $connection->real_escape_string($imagePath);

    $sql = "INSERT INTO projects (title, description, image) VALUES ('$title', '$description', '$imagePath')";

    if ($connection->query($sql) === FALSE) {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}


function updateProject($id, $title, $description, $imagePath, $connection) {
    $id = $connection->real_escape_string($id);
    $title = $connection->real_escape_string($title);
    $description = $connection->real_escape_string($description);
    $imagePath = $connection->real_escape_string($imagePath);

    $sql = "UPDATE projects SET title = '$title', description = '$description', image = '$imagePath' WHERE  id=$id";

    if ($conn->query($sql) === TRUE) {
echo "User updated successfully!";
} else {
echo "Error updating user: " . $conn->error;
}
}


function deleteUser($id) {
global $conn;
$sql = "DELETE FROM projects WHERE id=$id";
if ($conn->query($sql) === TRUE) {
echo "User deleted successfully!";
} else {
echo "Error deleting user: " . $conn->error;
}
}


function getProjects($connection) {
    $sql = "SELECT * FROM projects";
    $result = $connection->query($sql);
    $projects = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
    }

    return $projects;
}


function registerUser($username, $password, $connection) {
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $username = $connection->real_escape_string($username);

    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashedPassword')";

    if ($connection->query($sql) === FALSE) {
        echo "Error: " . $sql . "<br>" . $connection->error;
    }
}

function loginUser($username, $password, $connection) {
    $username = $connection->real_escape_string($username);

    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $connection->query($sql);

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            return true; 
        }
    }

    return false; 
}
?>



